// App.js
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import welcomescreen from './components/welcomescreen';
import RequestedQuizScreen from './components/RequestedQuizScreen';
import JavaScriptQuizScreen from './components/JavaScriptQuizScreen';
import PythonQuizScreen from './components/PythonQuizScreen';
import JavaQuizScreen from './components/JavaQuizScreen';
import CSharpQuizScreen from './components/CSharpQuizScreen';

const Stack = createStackNavigator();

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Welcome" headerMode="none">
        <Stack.Screen name="Welcome" component={welcomescreen} />
        <Stack.Screen name="RequestedQuiz" component={RequestedQuizScreen} />
        <Stack.Screen name="JavaScriptQuiz" component={JavaScriptQuizScreen} />
        <Stack.Screen name="PythonQuiz" component={PythonQuizScreen} />
        <Stack.Screen name="JavaQuiz" component={JavaQuizScreen} />
        <Stack.Screen name="CSharpQuiz" component={CSharpQuizScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App;
