import React, { useState } from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

const QuizScreen = () => {
  const [quizData, setQuizData] = useState([
    // Quiz data array containing questions, options, and correct answers
    {
      question: "What does HTML stand for in web development?",
      options: ["Hypertext Markup Language", "Hyperlink and Text Markup Language", "Home Tool Markup Language", "Hyper Task Management Language"],
      correctAnswer: "Hypertext Markup Language"
    },
    // Add more quiz questions here...
  ]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState(null);

  const currentQuestion = quizData[currentQuestionIndex];

  const handleAnswerSelection = (answer) => {
    setSelectedAnswer(answer);
  };

  const handleNextQuestion = () => {
    // Check answer, update score, etc.
    // Move to next question
    setCurrentQuestionIndex(currentQuestionIndex + 1);
    setSelectedAnswer(null); // Reset selected answer
  };

  // Check if currentQuestion is undefined before accessing its properties
  if (!currentQuestion) {
    return (
      <View style={styles.container}>
        <Text>No more questions</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.question}>{currentQuestion.question}</Text>
      {currentQuestion.options.map(option => (
        <Button key={option} title={option} onPress={() => handleAnswerSelection(option)} />
      ))}
      <Button title="Next Question" onPress={handleNextQuestion} disabled={!selectedAnswer} />
    </View>
  );
};
