import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { NavigationContainer } from '@react-navigation/native';

// Import your screens
import WelcomeScreen from './welcomescreen';
import ProfileInfoScreen from './ProfileInfoScreen';
import QuizHistoryScreen from './QuizHistoryScreen';
import RequestedQuizScreen from './RequestedQuizScreen';

const Tab = createBottomTabNavigator();

const BottomNavigation = () => {
  return (
    <NavigationContainer>
      <Tab.Navigator>
        <Tab.Screen name="Home" component={WelcomeScreen} />
        <Tab.Screen name="Profile" component={ProfileInfoScreen} />
        <Tab.Screen name="Quiz History" component={QuizHistoryScreen} />
        <Tab.Screen name="Requested Quiz" component={RequestedQuizScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
};

export default BottomNavigation;
