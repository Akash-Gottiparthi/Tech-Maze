import React, { useState } from 'react';
import { View, Text, Button } from 'react-native';

const CSharpQuizScreen = ({ navigation }) => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);

  const quizData = [
    { question: 'What is C#?', options: ['A programming language', 'A markup language', 'A scripting language', 'A database language'], correctAnswer: 'A programming language' },
    { question: 'What is the correct syntax for declaring a variable in C#?', options: ['variable name = value;', 'var name = value;', 'int name = value;', 'string name = value;'], correctAnswer: 'var name = value;' },
    { question: 'Which of the following is not a valid data type in C#?', options: ['bool', 'int', 'char[]', 'double[]'], correctAnswer: 'double[]' },
    { question: 'What is the output of the following code? \n\n int x = 5; \n int y = 3; \n int result = x + y; \n Console.WriteLine("Result: " + result);', options: ['Result: 8', 'Result: 53', 'Result: 15', 'Result: 35'], correctAnswer: 'Result: 8' },
    // Add more quiz questions
  ];

  const handleAnswer = (selectedAnswer) => {
    if (selectedAnswer === quizData[currentQuestionIndex].correctAnswer) {
      setScore(score + 1);
    }
    nextQuestion();
  };

  const nextQuestion = () => {
    if (currentQuestionIndex < quizData.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      // End of quiz, navigate to score screen
      navigation.navigate('QuizScore', { score: score });
    }
  };

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Question {currentQuestionIndex + 1}:</Text>
      <Text>{quizData[currentQuestionIndex].question}</Text>
      {quizData[currentQuestionIndex].options.map((option, index) => (
        <Button key={index} title={option} onPress={() => handleAnswer(option)} />
      ))}
    </View>
  );
};

export default CSharpQuizScreen;
