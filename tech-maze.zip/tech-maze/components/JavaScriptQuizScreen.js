import React, { useState } from 'react';
import { View, Text, Button } from 'react-native';

const JavaScriptQuizScreen = ({ navigation }) => {
  const quizData = [
    { question: 'What is the result of 2 + 2?', options: ['3', '4', '5', '6'], correctAnswer: '4' },
    { question: 'What is the correct way to declare a JavaScript variable?', options: ['v name = value;', 'var name = value;', 'variable name = value;', 'int name = value;'], correctAnswer: 'var name = value;' },
    // Add more quiz questions here
  ];

  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);

  const handleAnswer = (selectedOption) => {
    if (selectedOption === quizData[currentQuestionIndex].correctAnswer) {
      setScore(score + 1);
    }

    if (currentQuestionIndex === quizData.length - 1) {
      // Last question
      navigation.navigate('Score', { score });
    } else {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    }
  };

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Question {currentQuestionIndex + 1} / 10:</Text>
      <Text>{quizData[currentQuestionIndex].question}</Text>
      {quizData[currentQuestionIndex].options.map((option, index) => (
        <Button key={index} title={option} onPress={() => handleAnswer(option)} />
      ))}
    </View>
  );
};

export default JavaScriptQuizScreen;
