// ProfileInfoScreen.js
import React, { useEffect } from 'react';
import { View, Text } from 'react-native';

const ProfileInfoScreen = ({ navigation }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      navigation.navigate('Quizzes'); // Navigate to Quizzes after 1 second
    }, 1000); // 1 second delay

    return () => clearTimeout(timer);
  }, [navigation]);

  // Generate random username and password
  const username = "JohnDoe";
  const password = "12345";

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>User's Profile Information</Text>
      <Text>Username: {username}</Text>
      <Text>Password: {password}</Text>
    </View>
  );
};

export default ProfileInfoScreen;
