import React, { useState } from 'react';
import { View, Text, Button } from 'react-native';

const PythonQuizScreen = ({ navigation }) => {
  const quizData = [
    { question: 'What is the result of 3 + 5?', options: ['6', '7', '8', '9'], correctAnswer: '8' },
    { question: 'Which of the following is not a Python data type?', options: ['int', 'str', 'char', 'float'], correctAnswer: 'char' },
    // Add more quiz questions here
  ];

  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);

  const handleAnswer = (selectedOption) => {
    if (selectedOption === quizData[currentQuestionIndex].correctAnswer) {
      setScore(score + 1);
    }

    if (currentQuestionIndex === quizData.length - 1) {
      // Last question
      navigation.navigate('Score', { score });
    } else {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    }
  };

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Question {currentQuestionIndex + 1} / 10:</Text>
      <Text>{quizData[currentQuestionIndex].question}</Text>
      {quizData[currentQuestionIndex].options.map((option, index) => (
        <Button key={index} title={option} onPress={() => handleAnswer(option)} />
      ))}
    </View>
  );
};

export default PythonQuizScreen;
