import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const QuizHistoryScreen = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.heading}>User's Quiz History and Trending Quizzes</Text>
      {/* Display quiz history and trending quizzes here */}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
});

export default QuizHistoryScreen;
