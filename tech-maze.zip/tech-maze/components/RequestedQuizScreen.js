// RequestedQuizScreen.js
import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

const RequestedQuizScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Text>Requested Quiz Content</Text>
      <Text>Please choose a programming language:</Text>
      <View style={styles.buttonContainer}>
        <Button title="JavaScript" onPress={() => navigation.navigate('Quiz', { language: 'JavaScript' })} />
        <Button title="Python" onPress={() => navigation.navigate('Quiz', { language: 'Python' })} />
        <Button title="Java" onPress={() => navigation.navigate('Quiz', { language: 'Java' })} />
        <Button title="C#" onPress={() => navigation.navigate('Quiz', { language: 'C#' })} />
        {/* Add more programming language buttons as needed */}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  buttonContainer: {
    marginTop: 20,
  },
});

export default RequestedQuizScreen;
