// WelcomeScreen.js
import React, { useEffect } from 'react';
import { View, Text } from 'react-native';

const WelcomeScreen = ({ navigation }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      navigation.navigate('RequestedQuiz');
    }, 1000); // 1 second delay

    return () => clearTimeout(timer);
  }, [navigation]);

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Welcome to the App!</Text>
    </View>
  );
};

export default WelcomeScreen;
